<?php

namespace TEHAND\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TEHANDPlatformBundle extends Bundle
{
}
